//Essas constantes vazias sao necessarias para a ide reconhecer os parametros
//a configuracao verdadeira se encontra em '/control/constantes.php'
const SystemName = "";
const InstituicaoName = "";
const SystemNameExtenso = "";
const CargoAdm = "";
const CargoProf ="";
const CargoAluno ="";
const AtividadeName = "";